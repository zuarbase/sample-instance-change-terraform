from instance_state import handler

print("state")
e = {"pathParameters":  {"":""}}
handler(e, "")
e = {"pathParameters": {"slug":"test"}}
handler(e, "")
